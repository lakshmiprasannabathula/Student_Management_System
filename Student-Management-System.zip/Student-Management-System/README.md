# Student Management System

Basic Python CRUD project.